# Number Guessing Game

secret_number = 7

print("Welcome to the Number Guessing Game!")
guess = int(input("Guess a number between 1 and 10: "))

if guess == secret_number:
    print("Congratulations! You guessed the correct number.")
elif guess > secret_number:
    print("Too high! Try again.")
else:
    print("Too low! Try again.")
