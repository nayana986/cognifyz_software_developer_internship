import requests
from bs4 import BeautifulSoup

# URL of the website to scrape
url = "https://example.com"

# Fetch the webpage
response = requests.get(url)

if response.status_code == 200:
    soup = BeautifulSoup(response.text, "html.parser")

    # Find all headings (example: h2 tags)
    headings = soup.find_all("h2")

    print("Scraped Data (Headlines):\n")

    for index, heading in enumerate(headings, start=1):
        print(f"{index}. {heading.get_text(strip=True)}")

else:
    print("Failed to retrieve the webpage")
